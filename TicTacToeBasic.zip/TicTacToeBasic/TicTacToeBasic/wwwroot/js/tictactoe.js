﻿let board = ["", "", "", "", "", "", "", "", ""];
let currentPlayer = "X";
let gameActive = true;

document.querySelectorAll(".cell").forEach(cell => {
    cell.addEventListener("click", function () {
        let index = this.getAttribute("data-index");

        if (board[index] === "" && gameActive) {
            board[index] = currentPlayer;
            this.innerText = currentPlayer;

            if (checkWinner()) {
                document.getElementById("status").innerText = currentPlayer + " Wins!";
                gameActive = false;
            } else if (!board.includes("")) {
                document.getElementById("status").innerText = "It's a Draw!";
                gameActive = false;
            } else {
                currentPlayer = currentPlayer === "X" ? "O" : "X";
            }
        }
    });
});

document.getElementById("restartBtn").addEventListener("click", function () {
    board = ["", "", "", "", "", "", "", "", ""];
    gameActive = true;
    currentPlayer = "X";
    document.getElementById("status").innerText = "";
    document.querySelectorAll(".cell").forEach(cell => cell.innerText = "");
});

function checkWinner() {
    const winningCombinations = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
        [0, 4, 8], [2, 4, 6]             // Diagonals
    ];
    return winningCombinations.some(combination =>
        board[combination[0]] !== "" &&
        board[combination[0]] === board[combination[1]] &&
        board[combination[1]] === board[combination[2]]
    );
}
